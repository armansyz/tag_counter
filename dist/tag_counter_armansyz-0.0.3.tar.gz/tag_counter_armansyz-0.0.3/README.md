# Tag Counter

This package contains a program for the python beginners course.
Application counts the tags on a given url.

## Interfaces

There are two interfaces:
1. Command line interface
2. GUI